import app from "../src/app.js"

export default app;